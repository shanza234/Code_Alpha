package com.example.Quote

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
